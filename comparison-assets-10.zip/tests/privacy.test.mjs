import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const read=name=>fs.readFileSync(new URL('../'+name,import.meta.url),'utf8');
test('public package has empty collection defaults and no private catalogue fields',()=>{
 const seed=JSON.parse(read('collection-defaults.json'));
 for(const key of ['states','assignments','upgrades','vehicleEdits','propertyRecords'])assert.deepEqual(seed[key],{},key);
 assert.deepEqual(seed.garages,[]);
 for(const v of JSON.parse(read('vehicles.json'))){assert.ok(!['owned','watchlist'].includes(v.status));for(const key of ['automaticCategory','categoryBeforeUnobtainable','correctedWatchDefault','watchReason','owner','email','nickname','garagePlan','personalPhotos'])assert.ok(!Object.hasOwn(v,key),`${v.id}: ${key}`);}
});
test('browser policy blocks remote scripts, connections, images and form submission',()=>{
 const html=read('index.html');const policy=html.match(/http-equiv="Content-Security-Policy" content="([^"]+)"/)[1];
 for(const directive of ["script-src 'self'","connect-src 'self'","font-src 'self'","form-action 'none'","base-uri 'none'","frame-src 'none'","object-src 'none'"])assert.ok(policy.split('; ').includes(directive),directive);
 assert.match(html,/<meta name="referrer" content="no-referrer">/);
 assert.ok(!policy.includes("'unsafe-eval'"));assert.ok(!/script-src[^;]*'unsafe-inline'/.test(policy));
 assert.equal(policy.split('; ').find(d=>d.startsWith('img-src ')),"img-src 'self' blob: data:");
 assert.ok(!read('styles.css').includes('@import'));
 for(const match of read('styles.css').matchAll(/url\(([^)]+)\)/g)){assert.ok(!/https?:/.test(match[1]));const path=match[1].replaceAll("'",'').replaceAll('"','');if(!path.startsWith('data:'))assert.ok(fs.existsSync(new URL('../'+path,import.meta.url)),path);}
 assert.ok(!read('app.js').includes('this.src=this.dataset.fallback'));
});
test('duplicate imports cannot override model URLs and prototype keys are rejected',()=>{
 const app=read('app.js'),fn=app.split('\n').find(l=>l.startsWith('function installOwnedCopies()'));
 const context={vehicles:[{id:'comet2',image:'assets/vehicles/comet2.webp',source:'https://gtacars.net/gta5/comet2'}],localStorage:{getItem:()=>JSON.stringify([{id:'comet2-copy-test',copyOf:'comet2',source:'javascript:alert(1)',image:'https://invalid.example/private',name:'<img onerror=alert(1)>'}])}};
 vm.createContext(context);vm.runInContext(fn+';installOwnedCopies()',context);
 assert.equal(context.vehicles[1].image,'assets/vehicles/comet2.webp');assert.equal(context.vehicles[1].source,context.vehicles[0].source);assert.equal(context.vehicles[1].name,undefined);
 const clean=read('features.js').split('\n').find(l=>l.startsWith('function cleanObject('));vm.runInContext(clean,context);
 assert.throws(()=>vm.runInContext('cleanObject(JSON.parse(\'{"__proto__":{"stolen":true}}\'))',context),/Unsafe backup key/);
 assert.equal(vm.runInContext('cleanObject({nickname:"<img onerror=alert(1)>"}).nickname',context),'<img onerror=alert(1)>');
});
