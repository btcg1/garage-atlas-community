import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const read=n=>fs.readFileSync(new URL('../'+n,import.meta.url),'utf8');
const context={window:{},document:{addEventListener(){}}};vm.createContext(context);vm.runInContext(read('garage-presets.js'),context);
const api=context.window.AtlasGaragePresets;
const data=JSON.parse(read('vehicles.json'));const car=id=>data.find(v=>v.id===id);
const garage=id=>({presetId:id});
test('preset capacities split ordinary floors, restricted bays and hangar upgrades correctly',()=>{
 const p=api.presets;
 assert.equal(p.length,158);assert.equal(new Set(p.map(x=>x.id)).size,p.length);
 assert.equal(p.filter(x=>x.group==='eclipse-floors').reduce((s,x)=>s+x.capacity,0),50);
 assert.equal(p.filter(x=>x.group==='office-floors').reduce((s,x)=>s+x.capacity,0),60);
 assert.equal(p.filter(x=>x.group==='nightclub-floors').reduce((s,x)=>s+x.capacity,0),31);
 assert.equal(p.filter(x=>x.group==='arena-floors').reduce((s,x)=>s+x.capacity,0),27);
 assert.equal(p.filter(x=>x.group==='vinewood-floors').reduce((s,x)=>s+x.capacity,0),100);
 assert.deepEqual(Array.from(api.get('smuggler-hangar').capacityChoices,x=>x.value),[20,25,35,40]);
 assert.equal(api.get('unit-124-popular-street').capacity,2);assert.equal(api.get('4531-dry-dock-street').capacity,6);
 assert.throws(()=>api.metadata({presetId:'pegasus-concierge'}),/information only/);
});
test('aircraft, bikes and special models cannot reserve incompatible garages',()=>{
 assert.ok(api.matches(car('krieger'),garage('eclipse-floor-1')));
 assert.ok(!api.matches(car('hydra'),garage('eclipse-floor-1')));
 assert.ok(api.matches(car('hydra'),garage('smuggler-hangar')));
 assert.ok(!api.matches(car('krieger'),garage('smuggler-hangar')));
 assert.ok(api.matches(car('hakuchou2'),garage('mc-clubhouse-motorcycle-garage')));
 assert.ok(!api.matches(car('krieger'),garage('mc-clubhouse-motorcycle-garage')));
 assert.ok(api.matches(car('bmx'),{storageKind:'bicycles'}));
 assert.ok(!api.matches(car('bmx'),garage('eclipse-floor-1')));
 assert.ok(api.matches(car('toreador'),garage('kosatka-moon-pool-car-bay')));
 assert.ok(!api.matches(car('krieger'),garage('kosatka-moon-pool-car-bay')));
 assert.ok(api.matches(car('seasparrow2'),garage('kosatka-sparrow-bay')));
 assert.ok(!api.matches(car('seasparrow'),garage('kosatka-sparrow-bay')));
 assert.ok(api.matches(car('cerberus'),garage('arena-workshop-cerberus-bay')));
 assert.ok(!api.matches(car('cerberus'),garage('eclipse-floor-1')));
 assert.ok(api.matches({...car('toreador'),id:'toreador-copy-2',copyOf:'toreador'},garage('kosatka-moon-pool-car-bay')));
});
test('all preset model restrictions refer to real catalogue identifiers',()=>{
 const ids=new Set(data.map(x=>x.id));
 for(const p of api.presets){assert.match(p.source,/^https:\/\//,p.id);if(p.kind==='info')assert.equal(p.capacity,null);else assert.ok(Number.isInteger(p.capacity)&&p.capacity>0&&p.capacity<=100,p.id);for(const id of p.acceptedIds||[])assert.ok(ids.has(id),id);}
});
