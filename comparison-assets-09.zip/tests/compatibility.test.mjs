import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const read=f=>fs.readFileSync(new URL('../'+f,import.meta.url),'utf8');
const data=JSON.parse(read('compatibility.json'));
const vehicles=JSON.parse(read('vehicles.json'));
const vehicle=id=>vehicles.find(v=>v.id===id);
async function load(payload=data,fail=false){
  const window={dispatchEvent(){}};
  const ctx={window,Event,fetch:async()=>({ok:!fail,json:async()=>payload})};
  vm.createContext(ctx);vm.runInContext(read('compatibility.js'),ctx);
  await window.AtlasCompatibility.ready;
  return window.AtlasCompatibility;
}

test('Researched IDs refer to exact catalogue variants and retain published coverage',()=>{
  const ids=new Set(vehicles.map(v=>v.id));
  assert.equal(Object.keys(data.jammer).length,258);
  assert.equal(data.imaniFull.length,20);
  assert.equal(data.hsw.ids.length,31);
  assert.equal(data.bennys.length,31);
  assert.equal(new Set(data.bennys.flatMap(x=>x.donorIds)).size,32);
  for(const id of [...Object.keys(data.jammer),...data.imaniFull,...data.hsw.ids,...data.bennys.flatMap(x=>[x.id,...x.donorIds])])assert(ids.has(id),id);
  for(const id of data.imaniFull)assert(data.jammer[id],id);
  for(const entry of Object.values(data.jammer))assert(data.workshops[entry.workshop]);
  assert.deepEqual([...data.hsw.ids].sort(),vehicles.filter(v=>v.hsw).map(v=>v.id).sort());
});

test('Full Imani and jammer-only eligibility stay separate from personal installation',async()=>{
  const a=await load();
  assert.equal(a.get(vehicle('baller8')).imani,'full');
  assert(a.supports(vehicle('baller8'),'remote'));
  assert.equal(a.get(vehicle('kuruma')).imani,'jammer');
  assert(!a.supports(vehicle('kuruma'),'remote'));
  assert(!a.get(vehicle('kuruma2')).jammer);
  assert(a.matches(vehicle('kuruma'),'jammer-only'));
  assert(!a.matches(vehicle('baller8'),'jammer-only'));
  assert.match(a.badges(vehicle('kuruma')),/Jammer eligible/);
  assert.doesNotMatch(a.badges(vehicle('kuruma')),/installed/);
  assert.match(a.detail(vehicle('baller8')),/share an upgrade slot/);
});

test('Benny donors and converted model outcomes cannot be confused',async()=>{
  const a=await load();
  assert(a.get(vehicle('nero')).bennysDonor);
  assert(!a.get(vehicle('nero')).bennysCustom);
  assert(!a.supports(vehicle('nero'),'bennys'));
  assert(a.supports(vehicle('nero2'),'bennys'));
  assert.equal(a.get(vehicle('nero2')).donorIds[0],'nero');
  assert.match(a.detail(vehicle('nero')),/data-detail="nero2"/);
  assert(a.matches(vehicle('tornado2'),'bennys-donor'));
  assert(a.matches(vehicle('tornado3'),'bennys-donor'));
  assert(!a.matches(vehicle('tornado4'),'bennys-donor'));
  assert(!a.matches(vehicle('brioso'),'bennys'));
  assert(a.matches(vehicle('brioso2'),'bennys-donor'));
});

test('Similar names never transfer compatibility to NPC or unrelated variants',async()=>{
  const a=await load();
  for(const id of ['policeb','police','police2','police3','bison3','cargobob3','cargobob4','frogger2','l35','daemon'])assert(!a.get(vehicle(id)).jammer,id);
  for(const id of ['policeb2','police5','polbuffalo','bison','cargobob','cargobob2','frogger','l352','daemon2','rapidgt','rapidgt2'])assert(a.get(vehicle(id)).jammer,id);
  assert(a.get({...vehicle('baller8'),id:'owned-copy',copyOf:'baller8'}).remote);
  assert(a.get(vehicle('avenger3')).jammer);
  assert(!a.get(vehicle('avenger2')).jammer);
});

test('Special workshops, HSW platforms and source disagreement remain explicit',async()=>{
  const a=await load();
  assert.equal(a.get(vehicle('alphaz1')).workshop.label,'Hangar Aircraft Workshop');
  assert.match(a.detail(vehicle('avenger')),/on autopilot/);
  assert.match(a.detail(vehicle('terbyte')),/Bureau Tech/);
  assert.match(a.detail(vehicle('terbyte')),/Darnell Bros Garment Factory/);
  assert.match(a.detail(vehicle('banshee')),/PC Enhanced/);
  assert.match(a.detail(vehicle('banshee')),/PC Legacy/);
  assert(a.matches(vehicle('baller3'),'review'));
  assert(!a.matches(vehicle('baller3'),'jammer'));
});

test('Loaded JSON renders escaped names and links, and failed data stays usable',async()=>{
  const injected=structuredClone(data);injected.modelNames.nero2='<img src=x onerror=alert(1)>';
  const a=await load(injected);
  assert.match(a.detail(vehicle('nero')),/&lt;img/);
  assert.doesNotMatch(a.detail(vehicle('nero')),/<img/);
  const unavailable=await load(data,true);
  assert(unavailable.get(vehicle('banshee')).failed);
  assert.match(unavailable.detail(vehicle('banshee')),/could not load/);
  assert(unavailable.matches(vehicle('banshee'),'hsw'));
});
