import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const vehicles=JSON.parse(fs.readFileSync(new URL('../vehicles.json',import.meta.url)));
const root=new URL('../',import.meta.url);
test('every full-size car has a photographed reference or a documented exception',()=>{
 for(const v of vehicles.filter(v=>['Car','Amphibious_Automobile','Submarinecar'].includes(v.type))){
  const r=v.realReference;
  assert.ok(r?.image||r?.exception,`Unreviewed counterpart for ${v.id}`);
  if(r?.image){
   assert.equal(r.stockVerified,true,v.id);
   assert.match(r.source,/^https:\/\//,v.id);
   assert.ok(r.label&&r.credit,v.id);
   assert.ok(r.image.startsWith('assets/'),v.id);
   const b=fs.readFileSync(new URL(r.image,root));
   assert.equal(b.toString('ascii',0,4),'RIFF',v.id);
   assert.equal(b.toString('ascii',8,12),'WEBP',v.id);
  }
 }
});
test('reported missing and malformed comparisons remain corrected',()=>{
 for(const id of ['sm722','vorschlaghammer','schlagen','virgo'])assert.ok(vehicles.find(v=>v.id===id).realReference.image,id);
 assert.match(vehicles.find(v=>v.id==='virgo').inspiration.label,/eighth generation/);
 assert.match(vehicles.find(v=>v.id==='sm722').realReference.label,/Stirling Moss/);
 assert.equal(vehicles.find(v=>v.id==='vigilante').realReference.stockVerified,false);
});
