import {readFileSync,existsSync} from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import test from 'node:test';
const prefix=existsSync('public/app.js')?'public/':'';
const catalogue=JSON.parse(readFileSync(prefix+'vehicles.json'));
const source=readFileSync(prefix+'app.js','utf8'),features=readFileSync(prefix+'features.js','utf8');
const locked=catalogue.filter(v=>v.route==='not-obtainable'&&v.storage?.eligible!==true);
const code=['cannotKeep','state','options','changeState','validatePlan'].map(n=>source.split('\n').find(l=>l.startsWith('function '+n+'('))).join('\n')+'\n'+features.split('\n').find(l=>l.startsWith('function validateSnapshot('));
function context(){const c=vm.createContext({vehicles:catalogue,saved:{},assignments:{},garages:[],upgrades:{},propertyRecords:{},vehicleEdits:{},preferences:{},window:{},structuredClone,labels:{owned:'Owned',watchlist:'Watchlist','not-obtainable':'Not obtainable'},toast:()=>{},cleanObject:o=>structuredClone(o),validateUpgrades:o=>o,canPark:()=>true});vm.runInContext(code,c);return c;}
test('non-ownable models override stale owned and watchlist states and reject changes',()=>{assert.equal(locked.length,133);const c=context();for(const v of locked){c.v=v;for(const old of ['owned','watchlist']){c.saved[v.id]=old;assert.equal(vm.runInContext('state(v)',c),'not-obtainable',v.id);assert.equal(vm.runInContext("options('owned',v)",c),'<option value="not-obtainable" selected>Not obtainable</option>');vm.runInContext("changeState(v.id,'watchlist')",c);assert.equal(c.saved[v.id],old);}}assert.equal((source.match(/disabled aria-disabled="true" title="This exact model cannot be permanently owned"/g)||[]).length,2);});
test('imports remove impossible ownership and assignments, retaining valid garage records',()=>{const c=context();c.backup={format:'garage-atlas',states:{[locked[0].id]:'owned',adder:'owned'},garages:[{id:'g',name:'Test garage',capacity:10}],assignments:{[locked[0].id]:'g',adder:'g'}};const r=vm.runInContext('validateSnapshot(backup)',c);assert.equal(r.states[locked[0].id],'not-obtainable');assert(!r.assignments[locked[0].id]);assert.equal(r.assignments.adder,'g');assert.equal(r.garages[0].name,'Test garage');});
test('delisted cars and vehicles with permanent storage remain selectable',()=>{const c=context();for(const v of catalogue.filter(v=>v.route==='delisted'||v.storage?.eligible===true)){c.v=v;c.saved[v.id]='owned';assert.equal(vm.runInContext('state(v)',c),'owned',v.id);}});
